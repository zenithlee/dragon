﻿using UnityEngine;
using System.Collections;

public class LoadingScreenManager : Singleton<LoadingScreenManager> {

}
