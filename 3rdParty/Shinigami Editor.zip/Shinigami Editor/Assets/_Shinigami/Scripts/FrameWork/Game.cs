﻿using UnityEngine;
using System.Collections;

public class Game : Singleton<Game> {


}
